require("dotenv").config(); // Ensure env vars are loaded even if required before dotenv.config() in index.js
const nodemailer = require("nodemailer");
const VisitorLog = require("../models/VisitorLog");
const Post = require("../models/Post");
const Comment = require("../models/Comment");
const User = require("../models/User");
const EmailReportLog = require("../models/EmailReportLog");
const Ad = require("../models/Ad");

// In-memory debounce cache to prevent flooding notifications for the same IP/session within a short time window (10 mins)
const visitorAlertThrottle = new Map();
const VISITOR_ALERT_THROTTLE_MS = 10 * 60 * 1000; // 10 minutes

// In-memory debounce cache for client ad clicks and article read notifications (10 mins per client/session)
const clientAlertThrottle = new Map();
const CLIENT_ALERT_THROTTLE_MS = 10 * 60 * 1000; // 10 minutes

/**
 * Build a fresh nodemailer transporter using explicit Gmail SMTP settings.
 * Using host/port/secure directly is more reliable than the `service:"gmail"` shorthand,
 * which can silently pick up wrong port numbers in some environments.
 * Call this per-send so it always reflects the latest environment variables.
 */
function buildTransporter() {
    const emailUser = process.env.EMAIL_USER || "coslab.media@gmail.com";
    // Gmail App Passwords are 16-chars with NO spaces.
    // Strip surrounding quotes (if dotenv included them) and all whitespace.
    const rawPass = process.env.EMAIL_PASS || "";
    const emailPass = rawPass.replace(/^["']|["']$/g, "").replace(/\s+/g, "");

    if (!emailPass) {
        console.warn("⚠️  EMAIL_PASS is not set. Emails will fail until a valid Gmail App Password is configured.");
    } else {
        console.log(`[Email] Using Gmail App Password: ${emailPass.slice(0, 4)}**** (length: ${emailPass.length})`);
    }

    return nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true, // SSL for port 465
        auth: {
            user: emailUser,
            pass: emailPass,
        },
        tls: {
            rejectUnauthorized: false,
        },
        connectionTimeout: 30000,
        greetingTimeout: 15000,
        socketTimeout: 30000,
        pool: false,
    });
}

// Singleton transporter (created once; replaced if env changes)
let transporter = buildTransporter();

// Verify transporter connection on startup (non-blocking)
transporter.verify((error) => {
    if (error) {
        console.error("❌ Email transporter verification failed:", error.message);
        console.error("   → Ensure EMAIL_USER and EMAIL_PASS env vars are set correctly.");
        console.error("   → EMAIL_PASS must be a 16-char Gmail App Password (not your account password).");
        console.error("   → Generate one at: https://myaccount.google.com/apppasswords (2FA required)");
    } else {
        console.log("✅ Email transporter is ready to send messages (Gmail SMTP connected on port 465).");
    }
});

/**
 * Send a single email with automatic transporter rebuild on auth failure.
 * This ensures a stale transporter doesn't block all subsequent sends.
 */
async function sendMail(options) {
    try {
        return await transporter.sendMail(options);
    } catch (err) {
        // If it's an auth or connection error, rebuild the transporter and retry once
        if (err.code === "EAUTH" || err.code === "ECONNECTION" || err.responseCode === 535) {
            console.warn("⚠️  SMTP auth/connection failed — rebuilding transporter and retrying once...");
            transporter = buildTransporter();
            return await transporter.sendMail(options);
        }
        throw err;
    }
}

/**
 * Helper to split and sanitize comma, semicolon, newline, or whitespace separated emails.
 */
function extractEmailList(rawEmails) {
    if (!rawEmails) return [];
    if (Array.isArray(rawEmails)) {
        return rawEmails
            .flatMap(e => extractEmailList(e))
            .filter(Boolean);
    }
    if (typeof rawEmails !== "string") return [];

    return rawEmails
        .split(/[\s,;]+/)
        .map(e => e.trim().toLowerCase())
        .filter(e => e && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e));
}

/**
 * Fetch all registered user emails, active advertiser emails, and client posting emails (deduplicated).
 */
async function getAllRecipientEmails() {
    try {
        const emailSet = new Set();

        // 1. Registered active users
        const users = await User.find({ isActive: { $ne: false } }, "email");
        users.forEach(u => {
            extractEmailList(u.email).forEach(em => emailSet.add(em));
        });

        // 2. Active Advertisers
        const activeAds = await Ad.find({ isActive: true, clientEmail: { $exists: true, $ne: "" } }, "clientEmail");
        activeAds.forEach(a => {
            extractEmailList(a.clientEmail).forEach(em => emailSet.add(em));
        });

        // 3. All posts with client / brand emails attached
        const postsWithEmail = await Post.find({
            status: "published",
            email: { $exists: true, $ne: "" }
        }, "email");
        postsWithEmail.forEach(p => {
            extractEmailList(p.email).forEach(em => emailSet.add(em));
        });

        // Always include main company email as fallback
        emailSet.add("coslab.media@gmail.com");

        return Array.from(emailSet);
    } catch (err) {
        console.error("Error fetching recipient emails:", err);
        return ["coslab.media@gmail.com"];
    }
}

/**
 * Fetch primary admin notification emails (for instant alerts).
 */
async function getAdminAlertEmails() {
    try {
        const admins = await User.find({ role: "admin", isActive: { $ne: false } }, "email");
        const emailSet = new Set();
        admins.forEach(a => {
            if (a.email && a.email.trim()) emailSet.add(a.email.trim().toLowerCase());
        });
        emailSet.add("coslab.media@gmail.com");
        return Array.from(emailSet);
    } catch (err) {
        return ["coslab.media@gmail.com"];
    }
}

/**
 * Gather content & post inventory metrics (Posts made yesterday, scheduled posts, total platform posts, category breakdowns).
 */
async function gatherPostMetrics() {
    try {
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
        const startOfYesterday = new Date(startOfToday.getTime() - 24 * 60 * 60 * 1000);

        // 1. Posts made yesterday (createdAt between startOfYesterday and startOfToday)
        const yesterdayPostsRaw = await Post.aggregate([
            { $match: { createdAt: { $gte: startOfYesterday, $lt: startOfToday } } },
            { $group: { _id: "$category", count: { $sum: 1 } } },
            { $sort: { count: -1 } }
        ]);
        const postsYesterdayCount = yesterdayPostsRaw.reduce((sum, item) => sum + item.count, 0);
        const postsYesterdayCategories = yesterdayPostsRaw.map(item => ({
            category: item._id || "Uncategorized",
            count: item.count
        }));

        // 2. Total posts on entire platform & category breakdown
        const totalPlatformPosts = await Post.countDocuments();
        const publishedPostsCount = await Post.countDocuments({
            $or: [{ status: "published" }, { status: { $exists: false } }]
        });
        const draftPostsCount = await Post.countDocuments({ status: "draft" });

        const platformCategoriesRaw = await Post.aggregate([
            { $group: { _id: "$category", count: { $sum: 1 } } },
            { $sort: { count: -1 } }
        ]);
        const platformPostsCategories = platformCategoriesRaw.map(item => ({
            category: item._id || "Uncategorized",
            count: item.count
        }));

        // 3. Scheduled posts & category breakdown
        const scheduledPostsRaw = await Post.aggregate([
            { $match: { status: "scheduled" } },
            { $group: { _id: "$category", count: { $sum: 1 } } },
            { $sort: { count: -1 } }
        ]);
        const scheduledPostsCount = scheduledPostsRaw.reduce((sum, item) => sum + item.count, 0);
        const scheduledPostsCategories = scheduledPostsRaw.map(item => ({
            category: item._id || "Uncategorized",
            count: item.count
        }));

        const yesterdayDateString = startOfYesterday.toLocaleDateString("en-US", { 
            weekday: 'short', 
            month: 'short', 
            day: 'numeric', 
            year: 'numeric' 
        });

        return {
            postsYesterdayCount,
            postsYesterdayCategories,
            totalPlatformPosts,
            publishedPostsCount,
            draftPostsCount,
            platformPostsCategories,
            scheduledPostsCount,
            scheduledPostsCategories,
            yesterdayDateString
        };
    } catch (error) {
        console.error("Error in gatherPostMetrics:", error);
        return {
            postsYesterdayCount: 0,
            postsYesterdayCategories: [],
            totalPlatformPosts: 0,
            publishedPostsCount: 0,
            draftPostsCount: 0,
            platformPostsCategories: [],
            scheduledPostsCount: 0,
            scheduledPostsCategories: [],
            yesterdayDateString: "Yesterday"
        };
    }
}

/**
 * Render HTML section for Content & Publishing Metrics (Yesterday's Posts, Scheduled Posts, Total Platform Posts, Categories).
 */
function renderPostMetricsHtml(pm) {
    if (!pm) return "";

    const yesterdayCatChips = pm.postsYesterdayCategories.length > 0
        ? pm.postsYesterdayCategories.map(c => `
            <div style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; padding: 6px 12px; font-size: 12px; display: inline-block; margin-right: 6px; margin-bottom: 6px;">
                <strong style="color: #1e293b;">${c.category}:</strong> <span style="color: #0284c7; font-weight: 800;">${c.count}</span>
            </div>
        `).join("")
        : `<div style="font-size: 12px; color: #64748b; font-style: italic;">No posts created yesterday (${pm.yesterdayDateString}).</div>`;

    const scheduledCatChips = pm.scheduledPostsCategories.length > 0
        ? pm.scheduledPostsCategories.map(c => `
            <div style="background: #ffffff; border: 1px solid #fde68a; border-radius: 8px; padding: 6px 12px; font-size: 12px; display: inline-block; margin-right: 6px; margin-bottom: 6px;">
                <strong style="color: #78350f;">${c.category}:</strong> <span style="color: #d97706; font-weight: 800;">${c.count}</span>
            </div>
        `).join("")
        : `<div style="font-size: 12px; color: #64748b; font-style: italic;">No posts currently scheduled.</div>`;

    const platformCatRows = pm.platformPostsCategories.length > 0
        ? pm.platformPostsCategories.map(c => {
            const pct = pm.totalPlatformPosts > 0 
                ? ((c.count / pm.totalPlatformPosts) * 100).toFixed(1) 
                : "0.0";
            return `
                <tr>
                    <td><strong>${c.category}</strong></td>
                    <td style="text-align: right; font-weight: bold; color: #0f172a;">${c.count}</td>
                    <td style="text-align: right; color: #64748b; font-size: 12px;">${pct}%</td>
                </tr>
            `;
        }).join("")
        : `<tr><td colspan="3" style="text-align: center; color: #94a3b8;">No posts found on platform.</td></tr>`;

    return `
        <!-- Content Publishing Overview Cards -->
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px;">
            <div style="background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 12px; padding: 14px; text-align: center;">
                <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; color: #0284c7;">Yesterday's Posts</div>
                <div style="font-size: 22px; font-weight: 800; color: #0369a1; margin-top: 2px;">${pm.postsYesterdayCount}</div>
                <div style="font-size: 10px; color: #64748b; margin-top: 2px;">${pm.yesterdayDateString}</div>
            </div>
            <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 14px; text-align: center;">
                <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; color: #16a34a;">Total Platform Posts</div>
                <div style="font-size: 22px; font-weight: 800; color: #15803d; margin-top: 2px;">${pm.totalPlatformPosts}</div>
                <div style="font-size: 10px; color: #64748b; margin-top: 2px;">${pm.publishedPostsCount} Live • ${pm.scheduledPostsCount} Scheduled</div>
            </div>
            <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 14px; text-align: center;">
                <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; color: #d97706;">Scheduled Posts</div>
                <div style="font-size: 22px; font-weight: 800; color: #b45309; margin-top: 2px;">${pm.scheduledPostsCount}</div>
                <div style="font-size: 10px; color: #64748b; margin-top: 2px;">Queued for publish</div>
            </div>
        </div>

        <!-- Detailed Publishing Breakdown -->
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin-bottom: 25px;">
            <div style="font-size: 14px; font-weight: 800; color: #0f172a; margin-bottom: 8px;">
                📝 Posts Made Yesterday by Category (${pm.yesterdayDateString})
            </div>
            <div style="margin-bottom: 16px;">
                ${yesterdayCatChips}
            </div>

            <div style="font-size: 14px; font-weight: 800; color: #0f172a; margin-bottom: 8px;">
                ⏰ Scheduled Posts Queue by Category
            </div>
            <div style="margin-bottom: 16px;">
                ${scheduledCatChips}
            </div>

            <div style="font-size: 14px; font-weight: 800; color: #0f172a; margin-bottom: 10px;">
                📚 Platform Overall Category Distribution
            </div>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 0;">
                <thead>
                    <tr>
                        <th style="background: #f1f5f9; padding: 8px 10px; text-align: left; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0;">Category</th>
                        <th style="background: #f1f5f9; padding: 8px 10px; text-align: right; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0;">Total Articles</th>
                        <th style="background: #f1f5f9; padding: 8px 10px; text-align: right; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0;">Share</th>
                    </tr>
                </thead>
                <tbody>
                    ${platformCatRows}
                </tbody>
            </table>
        </div>
    `;
}

/**
 * Gather daily analytics & post metrics accurately.
 */
async function gatherDailyMetrics() {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
    const startOfWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const startOfMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    let dailyVisits = 0;
    const dailyUniqueIPs = new Set();
    let weeklyVisits = 0;
    let monthlyVisits = 0;
    let dailyClicks = 0;
    let dailyInteractions = 0;
    let dailyCommentsCount = 0;
    let approvedCommentsCount = 0;
    const topPostsToday = [];

    // 1. Visitor logs
    try {
        const allLogs = await VisitorLog.find();

        allLogs.forEach(log => {
            let activeToday = false;
            if (new Date(log.lastSeen) >= startOfToday || new Date(log.firstSeen) >= startOfToday) {
                activeToday = true;
            }

            if (log.pages && log.pages.length > 0) {
                log.pages.forEach(p => {
                    const vTime = new Date(p.visitedAt);
                    if (vTime >= startOfToday) {
                        dailyVisits += 1;
                        activeToday = true;
                    }
                    if (vTime >= startOfWeek) weeklyVisits += 1;
                    if (vTime >= startOfMonth) monthlyVisits += 1;
                });
            }

            if (activeToday && log.ip) {
                dailyUniqueIPs.add(log.ip);
            }

            if (log.buttons && log.buttons.length > 0) {
                log.buttons.forEach(b => {
                    if (new Date(b.clickedAt) >= startOfToday) dailyClicks += 1;
                });
            }

            if (log.postsInteracted && log.postsInteracted.length > 0) {
                log.postsInteracted.forEach(pi => {
                    if (new Date(pi.at) >= startOfToday) {
                        dailyInteractions += 1;
                    }
                });
            }
        });
    } catch (err) {
        console.error("Error fetching VisitorLogs in gatherDailyMetrics:", err);
    }

    // 2. Comments today
    try {
        dailyCommentsCount = await Comment.countDocuments({
            createdAt: { $gte: startOfToday }
        });

        approvedCommentsCount = await Comment.countDocuments({
            isApproved: true,
            createdAt: { $gte: startOfToday }
        });
    } catch (err) {
        console.error("Error fetching Comments in gatherDailyMetrics:", err);
    }

    // 3. Top posts today
    try {
        const topPostsDB = await Post.find({
            $or: [{ status: "published" }, { status: { $exists: false } }]
        })
            .sort({ views: -1 })
            .limit(5)
            .select("title views category slug");
        
        topPostsDB.forEach(p => {
            topPostsToday.push({ title: p.title, count: p.views || 0, category: p.category });
        });
    } catch (err) {
        console.error("Error fetching top posts in gatherDailyMetrics:", err);
    }

    // 4. Gather Post & Category publishing metrics
    const postMetrics = await gatherPostMetrics();

    return {
        dateString: now.toLocaleDateString("en-US", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
        dailyVisits,
        dailyUniqueVisitors: dailyUniqueIPs.size,
        weeklyVisits,
        monthlyVisits,
        dailyClicks,
        dailyInteractions,
        dailyCommentsCount,
        approvedCommentsCount,
        topPostsToday,
        postMetrics
    };
}

/**
 * Gather 7-day comprehensive weekly metrics (Thursday to Thursday) & post metrics safely.
 */
async function gatherWeeklyMetrics() {
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    let weeklyVisits = 0;
    const weeklyUniqueIPs = new Set();
    let weeklyClicks = 0;
    let weeklyInteractions = 0;
    let weeklyCommentsCount = 0;
    const topWeeklyPosts = [];

    // Day-by-day stats array for past 7 days
    const daysMap = {};
    for (let i = 6; i >= 0; i--) {
        const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        const dayKey = d.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
        daysMap[dayKey] = { day: dayKey, visits: 0, clicks: 0, interactions: 0 };
    }

    try {
        const allLogs = await VisitorLog.find();

        allLogs.forEach(log => {
            let activeWeekly = false;
            if (new Date(log.lastSeen) >= sevenDaysAgo || new Date(log.firstSeen) >= sevenDaysAgo) {
                activeWeekly = true;
            }

            if (log.pages && log.pages.length > 0) {
                log.pages.forEach(p => {
                    const vTime = new Date(p.visitedAt);
                    if (vTime >= sevenDaysAgo) {
                        weeklyVisits += 1;
                        activeWeekly = true;
                        const dayKey = vTime.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
                        if (daysMap[dayKey]) daysMap[dayKey].visits += 1;
                    }
                });
            }

            if (activeWeekly && log.ip) {
                weeklyUniqueIPs.add(log.ip);
            }

            if (log.buttons && log.buttons.length > 0) {
                log.buttons.forEach(b => {
                    const cTime = new Date(b.clickedAt);
                    if (cTime >= sevenDaysAgo) {
                        weeklyClicks += 1;
                        const dayKey = cTime.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
                        if (daysMap[dayKey]) daysMap[dayKey].clicks += 1;
                    }
                });
            }

            if (log.postsInteracted && log.postsInteracted.length > 0) {
                log.postsInteracted.forEach(pi => {
                    const iTime = new Date(pi.at);
                    if (iTime >= sevenDaysAgo) {
                        weeklyInteractions += 1;
                        const dayKey = iTime.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
                        if (daysMap[dayKey]) daysMap[dayKey].interactions += 1;
                    }
                });
            }
        });
    } catch (err) {
        console.error("Error fetching VisitorLogs in gatherWeeklyMetrics:", err);
    }

    try {
        weeklyCommentsCount = await Comment.countDocuments({
            createdAt: { $gte: sevenDaysAgo }
        });
    } catch (err) {
        console.error("Error fetching Comments in gatherWeeklyMetrics:", err);
    }

    try {
        const posts = await Post.find({
            $or: [{ status: "published" }, { status: { $exists: false } }]
        })
            .sort({ views: -1 })
            .limit(5)
            .select("title views category slug");
        posts.forEach(p => topWeeklyPosts.push(p));
    } catch (err) {
        console.error("Error fetching top posts in gatherWeeklyMetrics:", err);
    }

    // Gather Post & Category publishing metrics
    const postMetrics = await gatherPostMetrics();

    return {
        startDate: sevenDaysAgo.toLocaleDateString("en-US", { month: 'short', day: 'numeric' }),
        endDate: now.toLocaleDateString("en-US", { month: 'short', day: 'numeric', year: 'numeric' }),
        weeklyVisits,
        weeklyUniqueVisitors: weeklyUniqueIPs.size,
        weeklyClicks,
        weeklyInteractions,
        weeklyCommentsCount,
        dailyBreakdown: Object.values(daysMap),
        topWeeklyPosts,
        postMetrics
    };
}

/**
 * Send Daily Website Metrics Email Report.
 */
async function sendDailyReport(customRecipients = null) {
    const todayKey = new Date().toISOString().split("T")[0];
    try {
        const recipients = customRecipients || await getAllRecipientEmails();
        const m = await gatherDailyMetrics();

        const postMetricsHtml = renderPostMetricsHtml(m.postMetrics);

        const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #1e293b; }
                    .container { max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
                    .header { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 30px; text-align: center; color: #ffffff; }
                    .header h1 { margin: 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px; color: #38bdf8; }
                    .header p { margin: 6px 0 0 0; font-size: 13px; color: #94a3b8; }
                    .content { padding: 30px; }
                    .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 25px; }
                    .card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; text-align: center; }
                    .card-val { font-size: 24px; font-weight: 800; color: #0f172a; margin-top: 4px; }
                    .card-lbl { font-size: 11px; font-weight: 700; text-transform: uppercase; color: #64748b; }
                    .table-title { font-size: 15px; font-weight: 800; color: #0f172a; margin-bottom: 12px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 13px; }
                    th { background: #f1f5f9; padding: 10px 12px; text-align: left; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; }
                    td { padding: 10px 12px; border-bottom: 1px solid #f1f5f9; color: #334155; }
                    .footer { background: #f8fafc; padding: 20px; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Chemical Business Reports</h1>
                        <p>📊 Daily Executive Summary & Content Metrics • ${m.dateString}</p>
                    </div>
                    <div class="content">
                        <!-- Content & Publishing Metrics Section -->
                        ${postMetricsHtml}

                        <!-- Visitor Traffic & Interaction Metrics -->
                        <div class="table-title">📈 Visitor & Site Engagement</div>
                        <div class="grid">
                            <div class="card">
                                <div class="card-lbl">Today's Visits</div>
                                <div class="card-val" style="color: #0284c7;">${m.dailyVisits}</div>
                            </div>
                            <div class="card">
                                <div class="card-lbl">Unique Visitors</div>
                                <div class="card-val" style="color: #0d9488;">${m.dailyUniqueVisitors}</div>
                            </div>
                            <div class="card">
                                <div class="card-lbl">Weekly Total</div>
                                <div class="card-val" style="color: #6366f1;">${m.weeklyVisits}</div>
                            </div>
                            <div class="card">
                                <div class="card-lbl">Monthly Total</div>
                                <div class="card-val" style="color: #8b5cf6;">${m.monthlyVisits}</div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="card">
                                <div class="card-lbl">Total Button Clicks</div>
                                <div class="card-val">${m.dailyClicks}</div>
                            </div>
                            <div class="card">
                                <div class="card-lbl">Comments / Reviews</div>
                                <div class="card-val">${m.dailyCommentsCount}</div>
                            </div>
                        </div>

                        <div class="table-title">🔥 Top Performing Articles Today</div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Article Title</th>
                                    <th style="text-align: right;">Views / Interactions</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${m.topPostsToday.length > 0 ? m.topPostsToday.map(p => `
                                    <tr>
                                        <td><strong>${p.title}</strong></td>
                                        <td style="text-align: right; font-weight: bold; color: #0284c7;">${p.count}</td>
                                    </tr>
                                `).join("") : `
                                    <tr>
                                        <td colspan="2" style="text-align: center; color: #94a3b8;">No specific post interactions logged today.</td>
                                    </tr>
                                `}
                            </tbody>
                        </table>
                    </div>
                    <div class="footer">
                        <p>© ${new Date().getFullYear()} Chemical Business Reports. All rights reserved.</p>
                        <p>Sent automatically via coslab.media@gmail.com every day at 6:00 AM WAT.</p>
                    </div>
                </div>
            </body>
            </html>
        `;

        // Send individual email to each recipient
        const results = await Promise.allSettled(
            recipients.map(email =>
                transporter.sendMail({
                    from: '"Chemical Business Reports" <coslab.media@gmail.com>',
                    to: email,
                    subject: `📊 Daily Website & Content Metrics Report - ${m.dateString}`,
                    html: htmlContent
                })
            )
        );

        const succeeded = results.filter(r => r.status === "fulfilled");
        const failed    = results.filter(r => r.status === "rejected");

        succeeded.forEach((r) => {
            console.log(`Daily report sent to recipient — ${r.value.messageId}`);
        });
        failed.forEach((r) => {
            console.error(`Daily report FAILED for a recipient:`, r.reason?.message);
        });

        const lastId = succeeded.length > 0 ? succeeded[succeeded.length - 1].value.messageId : null;
        console.log(`Daily report: ${succeeded.length}/${recipients.length} delivered successfully.`);

        // Record in DB for persistent tracking
        await EmailReportLog.create({
            reportType: "daily",
            dateKey: todayKey,
            recipients,
            recipientsCount: succeeded.length,
            success: succeeded.length > 0,
            messageId: lastId || "",
            error: failed.length > 0 ? failed.map(f => f.reason?.message).join("; ") : "",
            metadata: {
                dailyVisits: m.dailyVisits,
                dailyUniqueVisitors: m.dailyUniqueVisitors,
                postsYesterday: m.postMetrics?.postsYesterdayCount || 0
            }
        });

        return { success: succeeded.length > 0, recipientsCount: succeeded.length, failedCount: failed.length, messageId: lastId };
    } catch (error) {
        console.error("Failed to send daily report email:", error);
        await EmailReportLog.create({
            reportType: "daily",
            dateKey: todayKey,
            success: false,
            error: error.message
        }).catch(() => {});
        return { success: false, error: error.message };
    }
}

/**
 * Send Weekly Thursday Comprehensive Email Report.
 */
async function sendWeeklyReport(customRecipients = null) {
    const now = new Date();
    const weekKey = `${now.getFullYear()}-W${Math.ceil((((now - new Date(now.getFullYear(), 0, 1)) / 86400000) + 1) / 7)}`;
    try {
        const recipients = customRecipients || await getAllRecipientEmails();
        const w = await gatherWeeklyMetrics();

        const postMetricsHtml = renderPostMetricsHtml(w.postMetrics);

        const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; color: #1e293b; }
                    .container { max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
                    .header { background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); padding: 35px; text-align: center; color: #ffffff; }
                    .header h1 { margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; }
                    .header p { margin: 6px 0 0 0; font-size: 13px; color: #e0f2fe; }
                    .content { padding: 30px; }
                    .summary-box { background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 12px; padding: 20px; margin-bottom: 25px; }
                    .summary-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; text-align: center; }
                    .sum-val { font-size: 22px; font-weight: 800; color: #0369a1; }
                    .sum-lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #0284c7; }
                    .table-title { font-size: 16px; font-weight: 800; color: #0f172a; margin: 25px 0 12px 0; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 13px; }
                    th { background: #f1f5f9; padding: 10px 12px; text-align: left; color: #475569; font-weight: 700; border-bottom: 2px solid #e2e8f0; }
                    td { padding: 10px 12px; border-bottom: 1px solid #f1f5f9; color: #334155; }
                    .footer { background: #f8fafc; padding: 20px; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Chemical Business Reports</h1>
                        <p>📈 Comprehensive Weekly Performance & Content Report (${w.startDate} - ${w.endDate})</p>
                    </div>
                    <div class="content">
                        <!-- Content & Publishing Metrics Section -->
                        ${postMetricsHtml}

                        <!-- Weekly Traffic Summary Box -->
                        <div class="table-title" style="margin-top: 10px;">📊 Weekly Traffic & Engagement Overview</div>
                        <div class="summary-box">
                            <div class="summary-grid">
                                <div>
                                    <div class="sum-lbl">7-Day Total Visits</div>
                                    <div class="sum-val">${w.weeklyVisits}</div>
                                </div>
                                <div>
                                    <div class="sum-lbl">Unique Visitors</div>
                                    <div class="sum-val">${w.weeklyUniqueVisitors}</div>
                                </div>
                                <div>
                                    <div class="sum-lbl">Total Button Clicks</div>
                                    <div class="sum-val">${w.weeklyClicks}</div>
                                </div>
                            </div>
                        </div>

                        <div class="table-title">📅 Day-by-Day Traffic Breakdown</div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Day</th>
                                    <th style="text-align: center;">Visits</th>
                                    <th style="text-align: center;">Button Clicks</th>
                                    <th style="text-align: right;">Post Interactions</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${w.dailyBreakdown.map(d => `
                                    <tr>
                                        <td><strong>${d.day}</strong></td>
                                        <td style="text-align: center; font-weight: bold; color: #0284c7;">${d.visits}</td>
                                        <td style="text-align: center;">${d.clicks}</td>
                                        <td style="text-align: right; color: #0d9488;">${d.interactions}</td>
                                    </tr>
                                `).join("")}
                            </tbody>
                        </table>

                        <div class="table-title">🏆 Top Published Articles This Week</div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Article Title</th>
                                    <th>Category</th>
                                    <th style="text-align: right;">Total Views</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${w.topWeeklyPosts.map(p => `
                                    <tr>
                                        <td><strong>${p.title}</strong></td>
                                        <td><span style="background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 12px; font-size: 11px;">${p.category}</span></td>
                                        <td style="text-align: right; font-weight: bold; color: #0284c7;">${p.views || 0}</td>
                                    </tr>
                                `).join("")}
                            </tbody>
                        </table>
                    </div>
                    <div class="footer">
                        <p>© ${new Date().getFullYear()} Chemical Business Reports. All rights reserved.</p>
                        <p>Sent automatically via coslab.media@gmail.com every Thursday at 8:00 AM WAT.</p>
                    </div>
                </div>
            </body>
            </html>
        `;

        // Send individual email to each recipient
        const results = await Promise.allSettled(
            recipients.map(email =>
                transporter.sendMail({
                    from: '"Chemical Business Reports" <coslab.media@gmail.com>',
                    to: email,
                    subject: `📈 Weekly Comprehensive Performance & Content Report (${w.startDate} - ${w.endDate})`,
                    html: htmlContent
                })
            )
        );

        const succeeded = results.filter(r => r.status === "fulfilled");
        const failed    = results.filter(r => r.status === "rejected");

        succeeded.forEach((r) => {
            console.log(`Weekly report sent to recipient — ${r.value.messageId}`);
        });
        failed.forEach((r) => {
            console.error(`Weekly report FAILED for a recipient:`, r.reason?.message);
        });

        const lastId = succeeded.length > 0 ? succeeded[succeeded.length - 1].value.messageId : null;
        console.log(`Weekly report: ${succeeded.length}/${recipients.length} delivered successfully.`);

        // Record in DB for persistent tracking
        await EmailReportLog.create({
            reportType: "weekly",
            dateKey: weekKey,
            recipients,
            recipientsCount: succeeded.length,
            success: succeeded.length > 0,
            messageId: lastId || "",
            error: failed.length > 0 ? failed.map(f => f.reason?.message).join("; ") : "",
            metadata: {
                weeklyVisits: w.weeklyVisits,
                weeklyUniqueVisitors: w.weeklyUniqueVisitors,
                weeklyClicks: w.weeklyClicks
            }
        });

        return { success: succeeded.length > 0, recipientsCount: succeeded.length, failedCount: failed.length, messageId: lastId };
    } catch (error) {
        console.error("Failed to send weekly report email:", error);
        await EmailReportLog.create({
            reportType: "weekly",
            dateKey: weekKey,
            success: false,
            error: error.message
        }).catch(() => {});
        return { success: false, error: error.message };
    }
}

/**
 * Send Instant Real-Time Visitor IP Arrival Alert.
 * Uses smart throttling per IP / session (10 mins) so email inbox stays pristine while capturing every visitor.
 */
async function sendVisitorAlertEmail({ ip, path, userAgent, sessionId, country, city, device }) {
    if (!ip || ip === "127.0.0.1" || ip === "::1" || ip === "localhost") {
        // Still allow alert if needed, but throttle
    }

    const throttleKey = `${ip}_${sessionId || "default"}`;
    const lastSent = visitorAlertThrottle.get(throttleKey);
    const now = Date.now();

    if (lastSent && (now - lastSent) < VISITOR_ALERT_THROTTLE_MS) {
        // Throttled: alert was already sent for this visitor session recently
        return { throttled: true };
    }

    visitorAlertThrottle.set(throttleKey, now);

    // Prune old cache entries if map grows large
    if (visitorAlertThrottle.size > 1000) {
        for (const [k, ts] of visitorAlertThrottle.entries()) {
            if (now - ts > VISITOR_ALERT_THROTTLE_MS) visitorAlertThrottle.delete(k);
        }
    }

    try {
        // Send notification immediately to ALL registered user emails in the database + main email
        const alertRecipients = await getAllRecipientEmails();
        const watTime = new Date().toLocaleString("en-US", { timeZone: "Africa/Lagos", dateStyle: "full", timeStyle: "medium" });

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8fafc; margin: 0; padding: 20px; color: #1e293b; }
                    .card { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 14px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
                    .hdr { background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); padding: 24px; text-align: center; color: #ffffff; }
                    .hdr h2 { margin: 0; font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
                    .hdr p { margin: 4px 0 0 0; font-size: 12px; color: #e0f2fe; }
                    .body { padding: 24px; }
                    .tag { display: inline-block; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 11px; text-transform: uppercase; background: #e0f2fe; color: #0369a1; margin-bottom: 15px; }
                    .row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
                    .lbl { color: #64748b; font-weight: 600; }
                    .val { font-weight: 700; color: #0f172a; font-family: monospace; }
                    .cta { display: block; text-align: center; background: #0284c7; color: #ffffff !important; padding: 12px 20px; border-radius: 8px; font-weight: 700; text-decoration: none; margin-top: 20px; font-size: 13px; }
                    .ftr { background: #f8fafc; padding: 16px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="hdr">
                        <h2>⚡ New Visitor IP Arrival Alert</h2>
                        <p>Chemical Business Reports Real-Time Traffic Monitor</p>
                    </div>
                    <div class="body">
                        <div class="tag">Live Visitor Detected on Platform</div>
                        <div class="row">
                            <span class="lbl">Visitor IP Address:</span>
                            <span class="val" style="color: #0284c7; font-size: 15px;">${ip}</span>
                        </div>
                        <div class="row">
                            <span class="lbl">Visited Page:</span>
                            <span class="val" style="font-family: inherit; color: #0f172a;">${path || "/"}</span>
                        </div>
                        <div class="row">
                            <span class="lbl">Arrival Time (WAT):</span>
                            <span class="val" style="font-family: inherit;">${watTime}</span>
                        </div>
                        ${country && country !== "Unknown" ? `
                        <div class="row">
                            <span class="lbl">Location:</span>
                            <span class="val" style="font-family: inherit;">${city ? city + ", " : ""}${country}</span>
                        </div>` : ""}
                        ${device ? `
                        <div class="row">
                            <span class="lbl">Device Type:</span>
                            <span class="val" style="font-family: inherit;">${device}</span>
                        </div>` : ""}
                        <div class="row" style="border-bottom: none;">
                            <span class="lbl">User Agent:</span>
                            <span class="val" style="font-size: 11px; word-break: break-all; font-family: inherit; color: #64748b;">${userAgent ? userAgent.slice(0, 100) + "..." : "Browser"}</span>
                        </div>

                        <a href="https://chemicalbusinessreports.com/admin/analytics" class="cta">
                            📊 View Live Visitor in Admin Detailed Report
                        </a>
                    </div>
                    <div class="ftr">
                        Sent automatically by Chemical Business Reports Platform • Instant Visitor Security & Traffic Monitor
                    </div>
                </div>
            </body>
            </html>
        `;

        const results = await Promise.allSettled(
            alertRecipients.map(email =>
                transporter.sendMail({
                    from: '"CBR Traffic Alert" <coslab.media@gmail.com>',
                    to: email,
                    subject: `⚡ New Visitor Arrival: ${ip} on ${path || "/"}`,
                    html
                })
            )
        );

        const succeeded = results.filter(r => r.status === "fulfilled");
        console.log(`Visitor alert sent to ${succeeded.length}/${alertRecipients.length} recipients for IP ${ip}`);

        return { success: succeeded.length > 0, recipientsCount: succeeded.length };
    } catch (err) {
        console.error("Error sending visitor alert email:", err);
        return { success: false, error: err.message };
    }
}

/**
 * Send Instant Notification for New Comment.
 */
async function sendNewCommentNotification({ authorName, authorEmail, authorPhone, content, postTitle, postId, isReply, replyToAuthor }) {
    try {
        const recipients = await getAdminAlertEmails();
        const contactInfo = [
            authorEmail ? `<strong>Email:</strong> <a href="mailto:${authorEmail}">${authorEmail}</a>` : null,
            authorPhone ? `<strong>Phone:</strong> <a href="tel:${authorPhone}">${authorPhone}</a>` : null,
        ].filter(Boolean).join(" &nbsp;|&nbsp; ");

        const replyBadge = isReply
            ? `<div style="background: #e0f2fe; color: #0369a1; padding: 4px 10px; border-radius: 6px; display: inline-block; font-size: 12px; font-weight: bold; margin-bottom: 8px;">↩ Replying to ${replyToAuthor || "a comment"}</div>`
            : "";

        const html = `
            <div style="font-family: sans-serif; max-width: 580px; margin: 0 auto; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; padding: 24px;">
                <h3 style="color: #0f172a; margin-top: 0;">💬 ${isReply ? "New Reply" : "New Comment"} Submitted for Moderation</h3>
                ${replyBadge}
                <p><strong>Article:</strong> ${postTitle || "Chemical Business Report"}</p>
                <p><strong>Author:</strong> ${authorName || "Anonymous"}</p>
                ${contactInfo ? `<p style="font-size: 13px; color: #64748b;">${contactInfo}</p>` : ""}
                <div style="background: #f8fafc; border-left: 4px solid #0284c7; padding: 12px 16px; margin: 15px 0; font-style: italic; color: #334155;">
                    "${content}"
                </div>
                <a href="https://chemicalbusinessreports.com/admin/comments" style="display: inline-block; background: #0284c7; color: #fff; padding: 10px 18px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 13px;">Review & Approve in Admin</a>
            </div>
        `;
        await Promise.allSettled(
            recipients.map(email =>
                transporter.sendMail({
                    from: '"CBR Notifications" <coslab.media@gmail.com>',
                    to: email,
                    subject: `💬 ${isReply ? "New Reply" : "New Comment"} from ${authorName || "User"} on "${postTitle ? postTitle.slice(0, 35) + "..." : "Article"}"`,
                    html
                })
            )
        );
    } catch (e) {
        console.error("Error sending comment alert:", e);
    }
}

/**
 * Send Instant Notification for New Subscription/Submission.
 */
async function sendNewSubmissionNotification({ name, email, company }) {
    try {
        const recipients = await getAdminAlertEmails();
        const html = `
            <div style="font-family: sans-serif; max-width: 580px; margin: 0 auto; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; padding: 24px;">
                <h3 style="color: #0f172a; margin-top: 0;">📬 New Newsletter / Platform Subscriber</h3>
                <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                    <tr><td style="padding: 6px 0; color: #64748b; font-weight: bold;">Name:</td><td>${name || "—"}</td></tr>
                    <tr><td style="padding: 6px 0; color: #64748b; font-weight: bold;">Email:</td><td><strong>${email}</strong></td></tr>
                    <tr><td style="padding: 6px 0; color: #64748b; font-weight: bold;">Company:</td><td>${company || "—"}</td></tr>
                </table>
                <p style="font-size: 12px; color: #94a3b8; margin-top: 20px;">Chemical Business Reports Subscriber Notification</p>
            </div>
        `;
        await Promise.allSettled(
            recipients.map(to =>
                transporter.sendMail({
                    from: '"CBR Notifications" <coslab.media@gmail.com>',
                    to,
                    subject: `📬 New Subscription: ${email} (${company || name || "Subscriber"})`,
                    html
                })
            )
        );
    } catch (e) {
        console.error("Error sending submission alert:", e);
    }
}

/**
 * Send Instant Notification for New Executive Profile Submission.
 */
async function sendNewExecutiveProfileNotification({ fullName, company, email, position }) {
    try {
        const recipients = await getAdminAlertEmails();
        const html = `
            <div style="font-family: sans-serif; max-width: 580px; margin: 0 auto; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; padding: 24px;">
                <h3 style="color: #0f172a; margin-top: 0;">👤 New Executive Profile Submitted</h3>
                <p><strong>Full Name:</strong> ${fullName}</p>
                <p><strong>Position / Role:</strong> ${position || "Executive"}</p>
                <p><strong>Company:</strong> ${company || "—"}</p>
                <p><strong>Email:</strong> ${email || "—"}</p>
                <a href="https://chemicalbusinessreports.com/admin" style="display: inline-block; background: #0284c7; color: #fff; padding: 10px 18px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 13px; margin-top: 15px;">View in Admin Dashboard</a>
            </div>
        `;
        await Promise.allSettled(
            recipients.map(to =>
                transporter.sendMail({
                    from: '"CBR Notifications" <coslab.media@gmail.com>',
                    to,
                    subject: `👤 New Executive Profile: ${fullName} (${company || "Executive"})`,
                    html
                })
            )
        );
    } catch (e) {
        console.error("Error sending executive profile alert:", e);
    }
}

/**
 * Send Instant Notification to Client / Advertiser when their Ad is clicked.
 * Includes throttling to avoid spamming the client's inbox for repeated clicks in the same session.
 */
async function sendAdClickClientNotification({ adTitle, clientEmail, clientName, path, ip, device, sessionId }) {
    if (!clientEmail || !clientEmail.trim()) {
        return { success: false, message: "No client email provided" };
    }

    const cleanEmail = clientEmail.trim().toLowerCase();
    const throttleKey = `adclick_${cleanEmail}_${sessionId || ip || "default"}`;
    const lastSent = clientAlertThrottle.get(throttleKey);
    const now = Date.now();

    if (lastSent && (now - lastSent) < CLIENT_ALERT_THROTTLE_MS) {
        return { throttled: true };
    }
    clientAlertThrottle.set(throttleKey, now);

    try {
        const watTime = new Date().toLocaleString("en-US", { timeZone: "Africa/Lagos", dateStyle: "full", timeStyle: "medium" });

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8fafc; margin: 0; padding: 20px; color: #1e293b; }
                    .card { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
                    .hdr { background: linear-gradient(135deg, #059669 0%, #047857 100%); padding: 26px; text-align: center; color: #ffffff; }
                    .hdr h2 { margin: 0; font-size: 21px; font-weight: 800; }
                    .hdr p { margin: 6px 0 0 0; font-size: 13px; color: #d1fae5; }
                    .body { padding: 26px; }
                    .greeting { font-size: 15px; color: #334155; margin-bottom: 18px; line-height: 1.5; }
                    .stat-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 16px; margin: 16px 0; }
                    .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
                    .row:last-child { border-bottom: none; }
                    .lbl { color: #64748b; font-weight: 600; }
                    .val { font-weight: 700; color: #0f172a; }
                    .cta { display: block; text-align: center; background: #059669; color: #ffffff !important; padding: 12px 20px; border-radius: 8px; font-weight: 700; text-decoration: none; margin-top: 22px; font-size: 13px; }
                    .ftr { background: #f8fafc; padding: 16px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="hdr">
                        <h2>🎯 New Ad Click Engagement Alert</h2>
                        <p>Chemical Business Reports Advertiser Intelligence</p>
                    </div>
                    <div class="body">
                        <div class="greeting">
                            Hello <strong>${clientName || "Valued Advertiser"}</strong>,
                            <br><br>
                            Great news! A visitor on <strong>Chemical Business Reports</strong> just clicked on your active advertisement campaign.
                        </div>

                        <div class="stat-box">
                            <div class="row">
                                <span class="lbl">Ad Campaign:</span>
                                <span class="val" style="color: #059669;">${adTitle || "Advertisement"}</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Engagement Time (WAT):</span>
                                <span class="val">${watTime}</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Page Placement:</span>
                                <span class="val">${path || "Website"}</span>
                            </div>
                            ${device ? `
                            <div class="row">
                                <span class="lbl">Visitor Device:</span>
                                <span class="val">${device}</span>
                            </div>` : ""}
                        </div>

                        <p style="font-size: 13px; color: #64748b; line-height: 1.6; margin-top: 15px;">
                            Your campaign continues to attract engaged chemical and allied industry professionals across our platform.
                        </p>

                        <a href="https://chemicalbusinessreports.com" class="cta">
                            Visit Chemical Business Reports
                        </a>
                    </div>
                    <div class="ftr">
                        © ${new Date().getFullYear()} Chemical Business Reports. Published by Coslab Media Concepts (Ltd).
                    </div>
                </div>
            </body>
            </html>
        `;

        await transporter.sendMail({
            from: '"CBR Ad Analytics" <coslab.media@gmail.com>',
            to: cleanEmail,
            subject: `🎯 New Visitor Click on your Ad: "${adTitle || "Campaign"}" - Chemical Business Reports`,
            html
        });

        console.log(`Ad click notification email sent to advertiser: ${cleanEmail}`);
        return { success: true };
    } catch (err) {
        console.error("Error sending ad click client notification:", err);
        return { success: false, error: err.message };
    }
}

/**
 * Send Instant Notification to Client / Brand / Executive when any article with their email is read.
 */
async function sendArticleReadClientNotification({ postTitle, category, clientEmail, companyName, path, ip, device, sessionId }) {
    if (!clientEmail || !clientEmail.trim()) {
        return { success: false, message: "No client email provided" };
    }

    const emailList = extractEmailList(clientEmail);
    if (emailList.length === 0) {
        return { success: false, message: "No valid recipient email provided" };
    }

    const watTime = new Date().toLocaleString("en-US", { timeZone: "Africa/Lagos", dateStyle: "full", timeStyle: "medium" });
    const categoryLabel = category || "Feature Story";
    const themeColor = (category === "Executive Brief" || category === "Corporate Profile") ? "#0284c7" : "#4f46e5";

    let sentCount = 0;

    for (const cleanEmail of emailList) {
        const throttleKey = `articleread_${cleanEmail}_${sessionId || ip || "default"}`;
        const lastSent = clientAlertThrottle.get(throttleKey);
        const now = Date.now();

        if (lastSent && (now - lastSent) < CLIENT_ALERT_THROTTLE_MS) {
            continue; // Throttled for this session/IP
        }
        clientAlertThrottle.set(throttleKey, now);

        try {
            const html = `
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <style>
                        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8fafc; margin: 0; padding: 20px; color: #1e293b; }
                        .card { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
                        .hdr { background: linear-gradient(135deg, ${themeColor} 0%, #1e1b4b 100%); padding: 26px; text-align: center; color: #ffffff; }
                        .hdr h2 { margin: 0; font-size: 21px; font-weight: 800; }
                        .hdr p { margin: 6px 0 0 0; font-size: 13px; color: #e0e7ff; }
                        .body { padding: 26px; }
                        .greeting { font-size: 15px; color: #334155; margin-bottom: 18px; line-height: 1.5; }
                        .stat-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; margin: 16px 0; }
                        .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
                        .row:last-child { border-bottom: none; }
                        .lbl { color: #64748b; font-weight: 600; }
                        .val { font-weight: 700; color: #0f172a; }
                        .cta { display: block; text-align: center; background: ${themeColor}; color: #ffffff !important; padding: 12px 20px; border-radius: 8px; font-weight: 700; text-decoration: none; margin-top: 22px; font-size: 13px; }
                        .reachout-box { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 10px; padding: 14px 16px; margin-top: 20px; }
                        .ftr { background: #f8fafc; padding: 16px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; line-height: 1.5; }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <div class="hdr">
                            <h2>📖 Article Readership Alert</h2>
                            <p>Chemical Business Reports Editorial Readership Monitor</p>
                        </div>
                        <div class="body">
                            <div class="greeting">
                                Hello <strong>${companyName || "Leader / Corporate Team"}</strong>,
                                <br><br>
                                A visitor on <strong>Chemical Business Reports</strong> is currently reading your published <strong>${categoryLabel}</strong> story!
                            </div>

                            <div class="stat-box">
                                <div class="row">
                                    <span class="lbl">Feature Article:</span>
                                    <span class="val" style="color: ${themeColor};">${postTitle || "Feature Story"}</span>
                                </div>
                                <div class="row">
                                    <span class="lbl">Category:</span>
                                    <span class="val">${categoryLabel}</span>
                                </div>
                                <div class="row">
                                    <span class="lbl">Read Time (WAT):</span>
                                    <span class="val">${watTime}</span>
                                </div>
                                ${device ? `
                                <div class="row">
                                    <span class="lbl">Reader Device:</span>
                                    <span class="val">${device}</span>
                                </div>` : ""}
                            </div>

                            <p style="font-size: 13px; color: #64748b; line-height: 1.6; margin-top: 15px;">
                                Your leadership insights and business coverage are actively reaching chemical manufacturers, suppliers, researchers, and executive decision-makers.
                            </p>

                            <a href="https://chemicalbusinessreports.com${path || ""}" class="cta">
                                View Your Article on Chemical Business Reports
                            </a>

                            <div class="reachout-box">
                                <p style="margin: 0; font-size: 12px; color: #1e3a8a; line-height: 1.5;">
                                    💬 <strong>Editorial Contact:</strong> Have an update or press release to add? Reach out back to us at <a href="mailto:coslab.media@gmail.com" style="color: #2563eb; font-weight: 700;">coslab.media@gmail.com</a>.
                                </p>
                            </div>
                        </div>
                        <div class="ftr">
                            © ${new Date().getFullYear()} Chemical Business Reports. Published by Coslab Media Concepts (Ltd).
                        </div>
                    </div>
                </body>
                </html>
            `;

            await transporter.sendMail({
                from: '"CBR Readership Monitor" <coslab.media@gmail.com>',
                replyTo: 'coslab.media@gmail.com',
                to: cleanEmail,
                subject: `📖 Visitor Reading Your ${categoryLabel}: "${postTitle ? postTitle.slice(0, 45) + "..." : "Story"}"`,
                html
            });

            sentCount++;
            console.log(`Article readership alert sent to client: ${cleanEmail}`);
        } catch (err) {
            console.error(`Error sending article readership alert to ${cleanEmail}:`, err);
        }
    }

    return { success: true, count: sentCount };
}

/**
 * Send Brand Mention / Story Update Notification to companies/brands tagged in an article.
 */
async function sendBrandStoryNotification({ post, isUpdate = false, customNote = "" }) {
    if (!post || !post.email) {
        return { success: false, message: "No recipient emails provided for this post" };
    }

    const recipients = extractEmailList(post.email);
    if (recipients.length === 0) {
        return { success: false, message: "No valid emails found in post email field" };
    }

    try {
        const postTitle = post.title || "Industry Feature Story";
        const category = post.category || "News Roundup";
        const postSlug = post.slug || "";
        const postExcerpt = post.excerpt || (post.content ? post.content.replace(/<[^>]*>/g, '').slice(0, 220) + "..." : "");
        const companyName = post.companyName || "";
        const postUrl = `https://chemicalbusinessreports.com/posts/${postSlug}`;
        const watTime = new Date().toLocaleString("en-US", { timeZone: "Africa/Lagos", dateStyle: "full", timeStyle: "medium" });

        const themeColor = "#2563eb";
        const subject = isUpdate
            ? `🔔 Story Update: "${postTitle.slice(0, 50)}${postTitle.length > 50 ? '...' : ''}" | Chemical Business Reports`
            : `📢 Mention Alert: Your Brand Featured on Chemical Business Reports: "${postTitle.slice(0, 45)}${postTitle.length > 45 ? '...' : ''}"`;

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f1f5f9; margin: 0; padding: 24px; color: #1e293b; }
                    .card { max-width: 620px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px rgba(0,0,0,0.06); }
                    .hdr { background: linear-gradient(135deg, #1e3a8a 0%, #0f172a 100%); padding: 32px 24px; text-align: center; color: #ffffff; }
                    .badge { display: inline-block; background: rgba(255,255,255,0.18); color: #93c5fd; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
                    .hdr h1 { margin: 0; font-size: 22px; font-weight: 800; line-height: 1.3; }
                    .hdr p { margin: 8px 0 0 0; font-size: 13px; color: #cbd5e1; }
                    .body { padding: 30px 24px; }
                    .greeting { font-size: 15px; color: #334155; line-height: 1.6; margin-bottom: 20px; }
                    .article-box { background: #f8fafc; border-left: 4px solid #2563eb; border-radius: 0 12px 12px 0; padding: 18px 20px; margin: 20px 0; }
                    .article-title { font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 6px; }
                    .article-meta { font-size: 12px; color: #64748b; margin-bottom: 10px; }
                    .article-excerpt { font-size: 13px; color: #475569; line-height: 1.5; font-style: italic; }
                    .cta-btn { display: block; text-align: center; background: #2563eb; color: #ffffff !important; padding: 14px 24px; border-radius: 10px; font-weight: 700; text-decoration: none; margin: 26px 0 20px 0; font-size: 14px; box-shadow: 0 4px 12px rgba(37,99,235,0.25); }
                    .reachout-box { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 18px 20px; margin-top: 24px; }
                    .reachout-title { font-size: 13px; font-weight: 700; color: #1e40af; margin-bottom: 6px; }
                    .reachout-text { font-size: 12.5px; color: #1e3a8a; line-height: 1.5; margin: 0; }
                    .reachout-email { font-weight: 700; color: #1d4ed8; text-decoration: underline; }
                    .ftr { background: #f8fafc; padding: 20px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; line-height: 1.6; }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="hdr">
                        <div class="badge">${isUpdate ? 'Story Update Alert' : 'Brand Feature & Mention'}</div>
                        <h1>Chemical Business Reports</h1>
                        <p>Nigeria & Africa's Premier Chemical & Industrial Intelligence Platform</p>
                    </div>
                    <div class="body">
                        <div class="greeting">
                            Hello <strong>${companyName || "Executive / Corporate Communications Team"}</strong>,
                            <br><br>
                            ${isUpdate
                                ? `We wanted to inform you that an update has just been published regarding your featured story in <strong>Chemical Business Reports</strong>:`
                                : `We are pleased to inform you that your brand/organization has been featured in our latest <strong>${category}</strong> editorial publication on <strong>Chemical Business Reports</strong>:`}
                        </div>

                        <div class="article-box">
                            <div class="article-title">${postTitle}</div>
                            <div class="article-meta">Category: <strong>${category}</strong> • Published: ${watTime} (WAT)</div>
                            ${postExcerpt ? `<div class="article-excerpt">&ldquo;${postExcerpt}&rdquo;</div>` : ""}
                        </div>

                        <a href="${postUrl}" class="cta-btn">
                            Read Full Story on Chemical Business Reports →
                        </a>

                        <div class="reachout-box">
                            <div class="reachout-title">
                                📬 Editorial Desk & Direct Reach-Out
                            </div>
                            <p class="reachout-text">
                                Have new press releases, executive updates, corrections, or partnership inquiries? 
                                You can reply directly to this email or reach out to our editorial desk anytime at 
                                <a href="mailto:coslab.media@gmail.com" class="reachout-email">coslab.media@gmail.com</a>.
                            </p>
                        </div>
                    </div>
                    <div class="ftr">
                        © ${new Date().getFullYear()} Chemical Business Reports. Published by Coslab Media Concepts (Ltd).<br>
                        Delivering strategic chemical, manufacturing, pharma, and business intelligence.
                    </div>
                </div>
            </body>
            </html>
        `;

        for (const recipient of recipients) {
            await transporter.sendMail({
                from: '"Chemical Business Reports Editorial" <coslab.media@gmail.com>',
                replyTo: 'coslab.media@gmail.com',
                to: recipient,
                subject,
                html
            });
            console.log(`Brand mention/update email dispatched to: ${recipient} for post: "${postTitle}"`);
        }

        return { success: true, count: recipients.length };
    } catch (err) {
        console.error("Error sending brand story notification:", err);
        return { success: false, error: err.message };
    }
}

/**
 * Broadcast New Article or Update to Registered Platform Users.
 */
async function sendPlatformUsersStoryUpdate({ post, isUpdate = false }) {
    if (!post) return { success: false, message: "No post provided" };

    try {
        const users = await User.find({ isActive: { $ne: false } }, "email username");
        const recipientSet = new Set();
        users.forEach(u => {
            extractEmailList(u.email).forEach(em => recipientSet.add(em));
        });

        const recipients = Array.from(recipientSet);
        if (recipients.length === 0) {
            return { success: true, count: 0, message: "No active platform users found" };
        }

        const postTitle = post.title || "Industry Feature Story";
        const category = post.category || "News Roundup";
        const postSlug = post.slug || "";
        const postExcerpt = post.excerpt || (post.content ? post.content.replace(/<[^>]*>/g, '').slice(0, 220) + "..." : "");
        const postUrl = `https://chemicalbusinessreports.com/posts/${postSlug}`;
        const watTime = new Date().toLocaleString("en-US", { timeZone: "Africa/Lagos", dateStyle: "full", timeStyle: "medium" });

        const subject = isUpdate
            ? `🔔 Article Updated: "${postTitle.slice(0, 50)}${postTitle.length > 50 ? '...' : ''}" | Chemical Business Reports`
            : `✨ New Intelligence: "${postTitle.slice(0, 50)}${postTitle.length > 50 ? '...' : ''}" | Chemical Business Reports`;

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f1f5f9; margin: 0; padding: 24px; color: #1e293b; }
                    .card { max-width: 620px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px rgba(0,0,0,0.06); }
                    .hdr { background: linear-gradient(135deg, #0f766e 0%, #0f172a 100%); padding: 30px 24px; text-align: center; color: #ffffff; }
                    .badge { display: inline-block; background: rgba(255,255,255,0.18); color: #a7f3d0; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
                    .hdr h1 { margin: 0; font-size: 22px; font-weight: 800; line-height: 1.3; }
                    .hdr p { margin: 8px 0 0 0; font-size: 13px; color: #cbd5e1; }
                    .body { padding: 30px 24px; }
                    .greeting { font-size: 15px; color: #334155; line-height: 1.6; margin-bottom: 20px; }
                    .article-box { background: #f8fafc; border-left: 4px solid #0f766e; border-radius: 0 12px 12px 0; padding: 18px 20px; margin: 20px 0; }
                    .article-title { font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 6px; }
                    .article-meta { font-size: 12px; color: #64748b; margin-bottom: 10px; }
                    .article-excerpt { font-size: 13px; color: #475569; line-height: 1.5; font-style: italic; }
                    .cta-btn { display: block; text-align: center; background: #0f766e; color: #ffffff !important; padding: 14px 24px; border-radius: 10px; font-weight: 700; text-decoration: none; margin: 26px 0 20px 0; font-size: 14px; }
                    .reachout-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 16px 20px; margin-top: 24px; }
                    .reachout-title { font-size: 13px; font-weight: 700; color: #166534; margin-bottom: 6px; }
                    .reachout-text { font-size: 12.5px; color: #14532d; line-height: 1.5; margin: 0; }
                    .ftr { background: #f8fafc; padding: 20px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; line-height: 1.6; }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="hdr">
                        <div class="badge">${isUpdate ? 'Platform Story Update' : 'New Publication'}</div>
                        <h1>Chemical Business Reports</h1>
                        <p>Industry Intelligence & Research Bulletin</p>
                    </div>
                    <div class="body">
                        <div class="greeting">
                            Hello CBR Reader,
                            <br><br>
                            ${isUpdate ? 'A fresh update has been made to the following story on our platform:' : 'A new article has just been published on Chemical Business Reports that may interest you:'}
                        </div>

                        <div class="article-box">
                            <div class="article-title">${postTitle}</div>
                            <div class="article-meta">Category: <strong>${category}</strong> • ${watTime} (WAT)</div>
                            ${postExcerpt ? `<div class="article-excerpt">&ldquo;${postExcerpt}&rdquo;</div>` : ""}
                        </div>

                        <a href="${postUrl}" class="cta-btn">
                            Read Full Article Now →
                        </a>

                        <div class="reachout-box">
                            <div class="reachout-title">Have News or Inquiries?</div>
                            <p class="reachout-text">
                                Reach out to our editorial desk anytime at <a href="mailto:coslab.media@gmail.com" style="color: #15803d; font-weight: 700;">coslab.media@gmail.com</a>.
                            </p>
                        </div>
                    </div>
                    <div class="ftr">
                        © ${new Date().getFullYear()} Chemical Business Reports. Published by Coslab Media Concepts (Ltd).
                    </div>
                </div>
            </body>
            </html>
        `;

        for (const recipient of recipients) {
            await transporter.sendMail({
                from: '"Chemical Business Reports" <coslab.media@gmail.com>',
                replyTo: 'coslab.media@gmail.com',
                to: recipient,
                subject,
                html
            }).catch(e => console.error(`Error sending platform user update to ${recipient}:`, e.message));
        }

        return { success: true, count: recipients.length };
    } catch (err) {
        console.error("Error broadcasting platform user story update:", err);
        return { success: false, error: err.message };
    }
}

/**
 * Auto-notification sent to advertiser/client upon successful launch of an Ad or Chemical Business Mart listing.
 * Includes duration, start & end dates, live link, and notice that daily performance updates (reach & viewers)
 * will be delivered automatically.
 */
async function sendAdListingLaunchNotification({
    itemType = "ad", // "ad" | "chemical_mart"
    title,
    clientEmail,
    clientName = "",
    durationDays = 30,
    startDate = new Date(),
    endDate,
    category = "Banner Advertisement",
    subcategory = "",
    adSize = "",
    companyName = "",
    productName = "",
    itemUrl = ""
}) {
    if (!clientEmail || !clientEmail.trim()) {
        return { success: false, message: "No client email provided" };
    }

    try {
        const isChemicalMart = itemType === "chemical_mart";
        const formattedStart = new Date(startDate).toLocaleDateString("en-US", {
            timeZone: "Africa/Lagos",
            year: "numeric",
            month: "short",
            day: "numeric"
        });
        const formattedEnd = endDate ? new Date(endDate).toLocaleDateString("en-US", {
            timeZone: "Africa/Lagos",
            year: "numeric",
            month: "short",
            day: "numeric"
        }) : "N/A";

        const subject = isChemicalMart
            ? `🎉 Your Chemical Business Mart Listing is Live: "${title}" (${durationDays} Days)`
            : `🚀 Your Campaign is Live: "${title}" (${durationDays} Days) — Chemical Business Reports`;

        const campaignTypeLabel = isChemicalMart ? "Chemical Business Mart Listing" : "Banner Advertisement";
        const displayName = clientName || companyName || "Valued Advertiser";
        const liveLink = itemUrl || "https://chemicalbusinessreports.com/posts/chemical-mart";

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f1f5f9; margin: 0; padding: 24px; color: #0f172a; }
                    .card { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05); }
                    .hdr { background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%); padding: 32px 28px; text-align: center; color: #ffffff; }
                    .badge-pill { display: inline-block; background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(4px); color: #ffffff; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; padding: 4px 14px; border-radius: 50px; margin-bottom: 12px; border: 1px solid rgba(255,255,255,0.3); }
                    .hdr h1 { margin: 0; font-size: 24px; font-weight: 800; line-height: 1.3; }
                    .hdr p { margin: 8px 0 0 0; font-size: 14px; color: #bfdbfe; }
                    .body { padding: 30px 28px; }
                    .greeting { font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.6; }
                    .details-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin: 20px 0; }
                    .row { display: flex; justify-content: space-between; align-items: center; padding: 9px 0; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
                    .row:last-child { border-bottom: none; }
                    .lbl { color: #64748b; font-weight: 600; }
                    .val { font-weight: 700; color: #0f172a; text-align: right; }
                    .update-promise-box { background: #eff6ff; border-left: 4px solid #2563eb; border-radius: 0 12px 12px 0; padding: 18px 20px; margin: 24px 0; }
                    .update-promise-box h4 { margin: 0 0 6px 0; color: #1e3a8a; font-size: 15px; font-weight: 700; }
                    .update-promise-box p { margin: 0; font-size: 13px; color: #1e40af; line-height: 1.6; }
                    .cta-btn { display: block; text-align: center; background: #2563eb; color: #ffffff !important; padding: 14px 24px; border-radius: 10px; font-weight: 700; text-decoration: none; margin: 26px 0 10px 0; font-size: 14px; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25); }
                    .contact-box { background: #fdfdfd; border-top: 1px solid #f1f5f9; padding: 16px; margin-top: 20px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.6; }
                    .contact-box a { color: #2563eb; font-weight: 700; text-decoration: none; }
                    .ftr { background: #0f172a; padding: 22px; text-align: center; font-size: 11px; color: #94a3b8; }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="hdr">
                        <div class="badge-pill">✅ Campaign Launched & Broadcasting</div>
                        <h1>Your Promotion is Officially Live!</h1>
                        <p>Chemical Business Reports — Market Intelligence & Advertising</p>
                    </div>
                    <div class="body">
                        <div class="greeting">
                            Dear <strong>${displayName}</strong>,
                            <br><br>
                            We are delighted to confirm that your <strong>${campaignTypeLabel}</strong> has been successfully launched across the <strong>Chemical Business Reports</strong> platform!
                        </div>

                        <div class="details-box">
                            <div class="row">
                                <span class="lbl">Campaign Title:</span>
                                <span class="val" style="color: #2563eb;">${title}</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Format / Placement:</span>
                                <span class="val">${campaignTypeLabel} ${subcategory ? `(${subcategory})` : ''}</span>
                            </div>
                            ${productName ? `
                            <div class="row">
                                <span class="lbl">Product Featured:</span>
                                <span class="val">${productName}</span>
                            </div>` : ''}
                            ${companyName ? `
                            <div class="row">
                                <span class="lbl">Company / Brand:</span>
                                <span class="val">${companyName}</span>
                            </div>` : ''}
                            ${adSize ? `
                            <div class="row">
                                <span class="lbl">Ad Size:</span>
                                <span class="val">${adSize}</span>
                            </div>` : ''}
                            <div class="row">
                                <span class="lbl">Duration:</span>
                                <span class="val" style="color: #059669; font-weight: 800;">${durationDays} Days</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Launch Date:</span>
                                <span class="val">${formattedStart} (WAT)</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Expiration Date:</span>
                                <span class="val">${formattedEnd} (WAT)</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Broadcast Status:</span>
                                <span class="val" style="color: #16a34a;">🟢 Active & Live</span>
                            </div>
                        </div>

                        <div class="update-promise-box">
                            <h4>📈 Daily Performance Tracking Updates</h4>
                            <p>
                                Starting today, you will receive automated <strong>daily updates</strong> directly in your inbox detailing how your campaign is performing in terms of <strong>reach (buyer impressions & views)</strong> and <strong>active viewers (clicks & reader engagements)</strong>. We are committed to giving you complete transparency and verifiable return on your marketing investment.
                            </p>
                        </div>

                        <a href="${liveLink}" class="cta-btn">
                            🌐 View Your Live Campaign on Chemical Business Reports
                        </a>

                        <div class="contact-box">
                            Need adjustments or want to extend your reach? Reach out to our advertising team at 
                            <a href="mailto:coslab.media@gmail.com">coslab.media@gmail.com</a>.
                        </div>
                    </div>
                    <div class="ftr">
                        © ${new Date().getFullYear()} Chemical Business Reports. Published by Coslab Media Concepts (Ltd).<br>
                        Connecting decision-makers across the chemical, cosmetic, food, and allied industries.
                    </div>
                </div>
            </body>
            </html>
        `;

        await sendMail({
            from: '"Chemical Business Reports Ad Desk" <coslab.media@gmail.com>',
            replyTo: 'coslab.media@gmail.com',
            to: clientEmail.trim().toLowerCase(),
            subject,
            html
        });

        console.log(`[Campaign Launch] 🚀 Launch email successfully sent to ${clientEmail} for "${title}"`);
        return { success: true };
    } catch (err) {
        console.error(`[Campaign Launch] Error sending launch email to ${clientEmail}:`, err);
        return { success: false, error: err.message };
    }
}

/**
 * Auto-notification sent when an ad or Chemical Mart listing is 48 hours or 24 hours from expiry.
 * Prompts the advertiser to renew their campaign to avoid interruption in reach.
 */
async function sendAdExpiryReminderNotification({
    itemType = "ad", // "ad" | "chemical_mart"
    title,
    clientEmail,
    clientName = "",
    companyName = "",
    durationDays = 30,
    expiryDate,
    hoursRemaining = 48,
    itemUrl = ""
}) {
    if (!clientEmail || !clientEmail.trim()) {
        return { success: false, message: "No client email provided" };
    }

    try {
        const is24h = hoursRemaining <= 24;
        const isChemicalMart = itemType === "chemical_mart";
        const campaignTypeLabel = isChemicalMart ? "Chemical Business Mart Listing" : "Advertisement Campaign";
        const displayName = clientName || companyName || "Valued Advertiser";

        const formattedExpiry = expiryDate ? new Date(expiryDate).toLocaleString("en-US", {
            timeZone: "Africa/Lagos",
            dateStyle: "full",
            timeStyle: "short"
        }) : "within the next 48 hours";

        const subject = is24h
            ? `🚨 URGENT: Your Campaign "${title}" expires in 24 hours — Renew to maintain reach`
            : `⏳ Reminder: Your Campaign "${title}" expires in 48 hours — Chemical Business Reports`;

        const headerBg = is24h
            ? "linear-gradient(135deg, #b91c1c 0%, #dc2626 100%)"
            : "linear-gradient(135deg, #b45309 0%, #d97706 100%)";

        const badgeText = is24h ? "🚨 EXPIRES IN 24 HOURS (FINAL REMINDER)" : "⏳ EXPIRES IN 48 HOURS";
        const renewSubject = encodeURIComponent(`Renew Campaign: ${title} (${campaignTypeLabel})`);
        const renewMailto = `mailto:coslab.media@gmail.com?subject=${renewSubject}&body=Hello%20CBR%20Advertising%20Team,%0D%0A%0D%0AI%20would%20like%20to%20renew%20my%20campaign:%20"${encodeURIComponent(title)}".%0D%0A%0D%0APlease%20let%20me%20know%20the%20available%20duration%20options%20and%20next%20steps.%0D%0A%0D%0AThank%20you!`;

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f1f5f9; margin: 0; padding: 24px; color: #0f172a; }
                    .card { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05); }
                    .hdr { background: ${headerBg}; padding: 32px 28px; text-align: center; color: #ffffff; }
                    .badge-pill { display: inline-block; background: rgba(255, 255, 255, 0.2); backdrop-filter: blur(4px); color: #ffffff; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; padding: 4px 14px; border-radius: 50px; margin-bottom: 12px; border: 1px solid rgba(255,255,255,0.3); }
                    .hdr h1 { margin: 0; font-size: 23px; font-weight: 800; line-height: 1.3; }
                    .hdr p { margin: 8px 0 0 0; font-size: 14px; color: #fef3c7; }
                    .body { padding: 30px 28px; }
                    .greeting { font-size: 16px; color: #334155; margin-bottom: 20px; line-height: 1.6; }
                    .alert-banner { background: ${is24h ? "#fef2f2" : "#fffbeb"}; border-left: 4px solid ${is24h ? "#ef4444" : "#f59e0b"}; border-radius: 0 12px 12px 0; padding: 18px 20px; margin: 20px 0; }
                    .alert-banner h4 { margin: 0 0 6px 0; color: ${is24h ? "#991b1b" : "#92400e"}; font-size: 15px; font-weight: 700; }
                    .alert-banner p { margin: 0; font-size: 13px; color: ${is24h ? "#b91c1c" : "#b45309"}; line-height: 1.6; }
                    .details-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin: 20px 0; }
                    .row { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
                    .row:last-child { border-bottom: none; }
                    .lbl { color: #64748b; font-weight: 600; }
                    .val { font-weight: 700; color: #0f172a; text-align: right; }
                    .cta-btn { display: block; text-align: center; background: ${is24h ? "#dc2626" : "#2563eb"}; color: #ffffff !important; padding: 15px 24px; border-radius: 10px; font-weight: 800; text-decoration: none; margin: 26px 0 12px 0; font-size: 15px; box-shadow: 0 4px 15px ${is24h ? "rgba(220, 38, 38, 0.3)" : "rgba(37, 99, 235, 0.25)"}; }
                    .contact-box { background: #fdfdfd; border-top: 1px solid #f1f5f9; padding: 16px; margin-top: 20px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.6; }
                    .contact-box a { color: #2563eb; font-weight: 700; text-decoration: none; }
                    .ftr { background: #0f172a; padding: 22px; text-align: center; font-size: 11px; color: #94a3b8; }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="hdr">
                        <div class="badge-pill">${badgeText}</div>
                        <h1>${is24h ? "Your Campaign Expires Tomorrow!" : "Campaign Expiration Notice"}</h1>
                        <p>Chemical Business Reports Advertising Desk</p>
                    </div>
                    <div class="body">
                        <div class="greeting">
                            Dear <strong>${displayName}</strong>,
                            <br><br>
                            This is an automatic notification that your <strong>${campaignTypeLabel}</strong> is scheduled to conclude its active broadcast cycle in <strong>${hoursRemaining} hours</strong>.
                        </div>

                        <div class="alert-banner">
                            <h4>⚠️ Keep Your Buyer Reach & Views Active</h4>
                            <p>
                                Once expired, your ad or listing will cease to be displayed to prospective buyers and industry decision-makers visiting Chemical Business Reports. Renew today to maintain uninterrupted exposure!
                            </p>
                        </div>

                        <div class="details-box">
                            <div class="row">
                                <span class="lbl">Campaign:</span>
                                <span class="val" style="color: #2563eb;">${title}</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Type:</span>
                                <span class="val">${campaignTypeLabel}</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Completed Duration:</span>
                                <span class="val">${durationDays} Days</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Scheduled Expiry:</span>
                                <span class="val" style="color: ${is24h ? '#dc2626' : '#d97706'}; font-weight: 800;">${formattedExpiry} (WAT)</span>
                            </div>
                            <div class="row">
                                <span class="lbl">Time Remaining:</span>
                                <span class="val" style="color: ${is24h ? '#dc2626' : '#d97706'}; font-weight: 800;">Approx. ${hoursRemaining} Hours</span>
                            </div>
                        </div>

                        <a href="${renewMailto}" class="cta-btn">
                            🔄 Click Here to Renew Your Campaign Now
                        </a>

                        ${itemUrl ? `
                        <p style="text-align: center; margin: 10px 0 0 0; font-size: 13px;">
                            <a href="${itemUrl}" style="color: #64748b; text-decoration: underline;">Review your live campaign before it expires →</a>
                        </p>` : ''}

                        <div class="contact-box">
                            Prefer to speak with an account manager? Reply directly to this email or write to 
                            <a href="mailto:coslab.media@gmail.com">coslab.media@gmail.com</a> to lock in your preferred placement.
                        </div>
                    </div>
                    <div class="ftr">
                        © ${new Date().getFullYear()} Chemical Business Reports. Published by Coslab Media Concepts (Ltd).<br>
                        Connecting decision-makers across the chemical, cosmetic, food, and allied industries.
                    </div>
                </div>
            </body>
            </html>
        `;

        await sendMail({
            from: '"Chemical Business Reports Ad Desk" <coslab.media@gmail.com>',
            replyTo: 'coslab.media@gmail.com',
            to: clientEmail.trim().toLowerCase(),
            subject,
            html
        });

        console.log(`[Expiry Reminder] ⏰ ${hoursRemaining}h reminder email sent to ${clientEmail} for "${title}"`);
        return { success: true };
    } catch (err) {
        console.error(`[Expiry Reminder] Error sending ${hoursRemaining}h reminder to ${clientEmail}:`, err);
        return { success: false, error: err.message };
    }
}

/**
 * Scans active Ads and Chemical Mart posts for expiration within 48h and 24h.
 * Dispatches automated reminder emails and updates schema flags to ensure no duplicates.
 */
async function checkAndSendAdExpiryReminders() {
    try {
        const now = new Date();
        const clientBaseUrl = process.env.CLIENT_URL || process.env.BASE_URL || "https://chemicalbusinessreports.com";
        let sentCount = 0;

        // 1. Check Banner Ads
        const activeAds = await Ad.find({
            isActive: true,
            endDate: { $exists: true, $gt: now },
            clientEmail: { $exists: true, $ne: "" }
        });

        for (const ad of activeAds) {
            const hoursLeft = (ad.endDate.getTime() - now.getTime()) / (1000 * 60 * 60);
            const itemUrl = ad.link && ad.link.startsWith("http") ? ad.link : `${clientBaseUrl}/posts/chemical-mart`;

            if (hoursLeft <= 48 && hoursLeft > 24 && !ad.reminder48hSent) {
                const res = await sendAdExpiryReminderNotification({
                    itemType: "ad",
                    title: ad.title,
                    clientEmail: ad.clientEmail,
                    clientName: ad.clientName,
                    durationDays: ad.durationDays,
                    expiryDate: ad.endDate,
                    hoursRemaining: 48,
                    itemUrl
                });
                if (res.success) {
                    ad.reminder48hSent = true;
                    await ad.save();
                    sentCount++;
                }
            } else if (hoursLeft <= 24 && hoursLeft > 0 && !ad.reminder24hSent) {
                const res = await sendAdExpiryReminderNotification({
                    itemType: "ad",
                    title: ad.title,
                    clientEmail: ad.clientEmail,
                    clientName: ad.clientName,
                    durationDays: ad.durationDays,
                    expiryDate: ad.endDate,
                    hoursRemaining: 24,
                    itemUrl
                });
                if (res.success) {
                    ad.reminder24hSent = true;
                    await ad.save();
                    sentCount++;
                }
            }
        }

        // 2. Check Chemical Mart Posts
        const activeMartPosts = await Post.find({
            category: "Chemical Mart",
            status: "published",
            expiryDate: { $exists: true, $gt: now },
            email: { $exists: true, $ne: "" }
        });

        for (const post of activeMartPosts) {
            const hoursLeft = (post.expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60);
            const itemUrl = `${clientBaseUrl}/posts/${post.slug || ""}`;

            if (hoursLeft <= 48 && hoursLeft > 24 && !post.reminder48hSent) {
                const res = await sendAdExpiryReminderNotification({
                    itemType: "chemical_mart",
                    title: post.title,
                    clientEmail: post.email,
                    clientName: post.companyName || post.author || "Valued Advertiser",
                    companyName: post.companyName,
                    durationDays: post.adDuration || 30,
                    expiryDate: post.expiryDate,
                    hoursRemaining: 48,
                    itemUrl
                });
                if (res.success) {
                    post.reminder48hSent = true;
                    await post.save();
                    sentCount++;
                }
            } else if (hoursLeft <= 24 && hoursLeft > 0 && !post.reminder24hSent) {
                const res = await sendAdExpiryReminderNotification({
                    itemType: "chemical_mart",
                    title: post.title,
                    clientEmail: post.email,
                    clientName: post.companyName || post.author || "Valued Advertiser",
                    companyName: post.companyName,
                    durationDays: post.adDuration || 30,
                    expiryDate: post.expiryDate,
                    hoursRemaining: 24,
                    itemUrl
                });
                if (res.success) {
                    post.reminder24hSent = true;
                    await post.save();
                    sentCount++;
                }
            }
        }

        return { success: true, sentCount };
    } catch (err) {
        console.error("Error checking ad expiry reminders:", err);
        return { success: false, error: err.message };
    }
}

/**
 * Fetch past report execution logs for Admin Dashboard.
 */
async function getRecentReportLogs(limit = 20) {
    try {
        return await EmailReportLog.find().sort({ sentAt: -1 }).limit(limit).lean();
    } catch (err) {
        console.error("Error fetching report logs:", err);
        return [];
    }
}

module.exports = {
    sendDailyReport,
    sendWeeklyReport,
    sendVisitorAlertEmail,
    sendNewCommentNotification,
    sendNewSubmissionNotification,
    sendNewExecutiveProfileNotification,
    sendAdClickClientNotification,
    sendArticleReadClientNotification,
    sendBrandStoryNotification,
    sendPlatformUsersStoryUpdate,
    sendAdListingLaunchNotification,
    sendAdExpiryReminderNotification,
    checkAndSendAdExpiryReminders,
    extractEmailList,
    getRecentReportLogs,
    gatherDailyMetrics,
    gatherWeeklyMetrics,
    gatherPostMetrics,
    getAllRecipientEmails,
    getAdminAlertEmails
};

